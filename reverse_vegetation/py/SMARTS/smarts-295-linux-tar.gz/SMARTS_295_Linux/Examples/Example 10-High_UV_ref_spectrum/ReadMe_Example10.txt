	READ ME -- Example 10:

SMARTS 2.9.5 Version of a reference UV spectrum

This example produces results for the same atmospheric conditions as the 
ASTM G177-03 reference spectrum. However: 
 (i)  some absorption and scattering functions have been improved in the model; 
 (ii) the NEW Gueymard Extraterrestrial Spectrum is used.
 
Thus this input file does NOT reproduce ASTM G177-03 EXACTLY. 

SMARTS 2.9.2 MUST be used to produce a true wavelength-by-wavelength replica of 
the ASTM G177-03 reference standard spectrum!
