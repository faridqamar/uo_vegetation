	READ ME -- Example 11:

Irradiance on vertical surfaces.
Thiese calculations refer to Chapter 5 ('Solar Spectral Radiation', by 
C.A. Gueymard and H.D. Kambezidis) of this textbook:

   T. Muneer, Solar radiation and daylight models, 2nd ed., Elsevier, 2004.

This example produces spectra on vertical surfaces, simulating an ideal 
building located at an altitude of 500 m and surrounded by lawn (green grass).
This particular example is for a south orientation and three air mass values.

Illuminances are also calculated for daylighting applications.
