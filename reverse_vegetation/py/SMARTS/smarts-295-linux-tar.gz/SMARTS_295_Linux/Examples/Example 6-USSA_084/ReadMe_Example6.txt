READ ME -- Example 6:

SMARTS 2.9.5 Version of a reference terrestrial spectrum

This example produces results for the same atmospheric conditions as 
ASTM G173-03 reference spectra. However: 
 (i)  some absorption and scattering functions have been improved in the model; 
 (ii) the NEW Gueymard Extraterrestrial Spectrum is used.
 
Thus this input file does NOT reproduce ASTM G173-03 EXACTLY. 

SMARTS 2.9.2 MUST be used to produce a true wavelength-by-wavelength replica of 
the ASTM G173-03 reference standard spectra!