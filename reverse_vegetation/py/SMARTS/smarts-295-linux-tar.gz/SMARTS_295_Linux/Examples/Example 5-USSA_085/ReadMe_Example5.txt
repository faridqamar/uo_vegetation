	READ ME -- Example 5: Revised USSA reference spectrum

This example is a variation of Example 1. The same conditions are used, except 
that:
- The aerosol optical depth at 500 nm is reduced from 0.27 to 0.085.
- The lower limit for the spectrum is now 280 nm.
- The maximum resolution (in particular, 0.5 nm in the UV) is to be used.